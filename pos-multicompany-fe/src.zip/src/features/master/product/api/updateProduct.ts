import axios from "axios";

import { apiClient, getCsrfCookie } from "@/lib/apiClient";
import type { ApiErrorResponse } from "@/types";
import type { ProductResponse, ProductUpdateRequest } from "../types";

export const updateProduct = async (
  companyId: number,
  productId: number,
  product: ProductUpdateRequest,
): Promise<string> => {
  try {
    await getCsrfCookie();
    const response = await apiClient.patch<ProductResponse>(
      `/companies/${companyId}/products/${productId}`,

      product,
    );

    return response.data.message;
  } catch (error: unknown) {
    if (axios.isAxiosError<ApiErrorResponse>(error)) {
      throw (
        error.response?.data ?? {
          message: "Failed to update product. Please try again.",
        }
      );
    }

    throw error;
  }
};
