import { useState } from "react";
import { Eye, EyeOff } from "lucide-react";
import type { LoginDataRequest } from "../types";
import { useForm, type SubmitHandler } from "react-hook-form";
import { login } from "../api/login";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/context/auth/AuthContext";
import SignupModal from "./SignupModal";
import { Spinner } from "@/components/ui/spinner";
import FormLogo from "@/components/ui/FormLogo";

export default function LoginForm() {
  const [signupOpen, setSignupOpen] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const navigate = useNavigate();
  const { refreshUser } = useAuth();
  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
  } = useForm<LoginDataRequest>();

  const onSubmit: SubmitHandler<LoginDataRequest> = async (data) => {
    try {
      await login(data);
      refreshUser();
      navigate("/dashboard");
    } catch (error: unknown) {
      if (error instanceof Error) {
        setErrorMessage(error.message);
      } else {
        setErrorMessage("Terjadi kesalahan. Silakan coba lagi.");
      }
    }
  };

  return (
    <div className="h-full w-full md:w-2/3 lg:w-1/3 px-20 justify-center lg:mb-30 flex flex-col items-center z-50">
      <FormLogo className="mb-8 w-[90%]" />
      <p className="self-start text-2xl font-bold text-white">Login</p>

      <div className="w-full mt-8">
        <form className="gap-4 flex flex-col" onSubmit={handleSubmit(onSubmit)}>
          <div>
            <input
              type="text"
              placeholder="Email"
              {...register("email", {
                required: "Email is required",
                pattern: {
                  value: /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
                  message: "Invalid email address",
                },
              })}
              className="w-full text-white placeholder:text-white lg:placeholder:text-gray-500 border-2 border-white lg:border-gray-500 rounded-md py-2 px-4 focus:outline-none focus:ring-1 focus:ring-gray-400"
            />
            {errors.email && (
              <span className="ml-2 text-red-500 text-xs">
                {errors.email.message}
              </span>
            )}
          </div>
          {/* <div>
            <input
              type="text"
              placeholder="Device Name"
              {...register("device_name", {
                required: "Device name is required",
              })}
              className="w-full text-gray-500 placeholder:text-white lg:placeholder:text-gray-500 border-2 border-white lg:border-gray-500 rounded-md py-2 px-4 focus:outline-none focus:ring-1 focus:ring-gray-400"
            />
            {errors.device_name && (
              <span className="ml-2 text-red-500 text-xs">
                {errors.device_name.message}
              </span>
            )}
          </div> */}

          <div className="relative w-full">
            <input
              type={showPassword ? "text" : "password"}
              placeholder="Password"
              {...register("password", {
                required: "Password is required",
                minLength: {
                  value: 8,
                  message: "Password must be at least 8 characters long",
                },
              })}
              className="w-full text-white placeholder:text-white lg:placeholder:text-gray-500 border-2 border-white lg:border-gray-500 rounded-md py-2 pl-4 pr-11 focus:outline-none focus:ring-1 focus:ring-gray-400"
            />

            <button
              type="button"
              onClick={() => setShowPassword(!showPassword)}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-white lg:text-gray-500 hover:text-gray-700"
              aria-label={
                showPassword ? "Sembunyikan password" : "Tampilkan password"
              }
            >
              {showPassword ? <EyeOff size={20} /> : <Eye size={20} />}
            </button>
            {errors.password && (
              <span className="ml-2 text-red-500 text-xs">
                {errors.password.message}
              </span>
            )}
          </div>

          {errorMessage && (
            <p className="text-center my-2 text-red-500 text-xs">{errorMessage}</p>
          )}

          <button
            type="submit"
            className="bg-blue-400 w-full flex justify-center items-center gap-2 text-white font rounded-md py-2 px-4 hover:bg-blue-500"
          >
            Login
            {isSubmitting && <Spinner />}
          </button>
        </form>
      </div>

      <p className="text-sm text-gray-400 mt-4">
        Dont have an account?{" "}
        <span onClick={() => setSignupOpen(true)} className="text-gray-200 md:text-blue-400  hover:underline">
          Sign up
        </span>
      </p>

     <SignupModal open={signupOpen} onOpenChange={setSignupOpen} /> 

    </div>
  );
}
